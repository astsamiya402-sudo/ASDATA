# ASDATA Backend – VTUGATE

Wannan backend yana kare VTUGATE API Key daga Android app. Android ba zai rike API Key ba; backend ne kawai zai rike shi.

## Abin da yake yi

- `GET /health` – duba ko server ya tashi.
- `POST /api/data-plans` – yana kiran `POST /api/v1/fetchdataplans` na VTUGATE.
- `POST /api/buy-data` – yana kiran `POST /api/v1/buydata` na VTUGATE.

## Muhimmin tsaro

Kada ka saka real/Test API Key a cikin Java/Android code, screenshots, GitHub, ko chat.

## Mataki na gaba

1. A kan computer/server mai Node.js 18+, kwafi `.env.example` zuwa `.env`.
2. Saka Test API Key a `VTUGATE_API_KEY` a cikin `.env`.
3. Gudanar da `npm install` sannan `npm start`.
4. A Android app, URL ɗin backend ne za a kira, ba VTUGATE kai tsaye ba.

Misalin request zuwa backend:

```json
POST /api/data-plans
{"service_id": 1}
```

```json
POST /api/buy-data
{
  "service_id": "149",
  "phone_number": "08012345678",
  "amount": 350,
  "plan_code": "1"
}
```

A VTUGATE, `service_id` da `plan_code` dole su fito daga **row ɗaya** na Fetch Data Plans, kuma amount ya yi daidai da price na wannan plan.

### Sandbox

Fara da Test API Key. A VTUGATE Sandbox, transactions ba su rage real wallet ba. Kada a canza zuwa live key sai bayan an kammala gwaji kuma an tabbatar da tsarin tsaro.
